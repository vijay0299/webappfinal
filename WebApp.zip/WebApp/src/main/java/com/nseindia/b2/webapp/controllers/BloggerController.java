package com.nseindia.b2.webapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
//import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.nseindia.b2.webapp.models.Blogger;
import com.nseindia.b2.webapp.models.Response;



@Controller
public class BloggerController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@RequestMapping
	public String index() {
		return "index";
	}
	
	@RequestMapping("/blogger")
	public String admin(Model model) {
		Blogger list = restTemplate.getForObject("http://localhost:8082", Blogger.class);
		model.addAttribute(list);
		model.addAttribute("Title", list.getTitle());
		model.addAttribute("Body", list.getBody());
		model.addAttribute("Summary", list.getSummary());
	
		return "blogger"; 
	}
	
	@GetMapping("/blogger/add")
	public String getAddBlogger() {
		return "bloggerDetails";
	}
	
	@PostMapping("/blogger/add")
	public String postAddBlogger(@RequestParam("title") String title, @RequestParam("body") String body,@RequestParam("summary") String summary, Model model) {
		
		Blogger blogger = new Blogger();
		blogger.setTitle(title);
		blogger.setBody(body);
		blogger.setSummary(summary);
		
		Response resp = restTemplate.postForObject("http://localhost:8082/", blogger, Response.class);
		
		model.addAttribute("message",resp.getBlogger());
		
		return "bloggerDetails";
	}

}
