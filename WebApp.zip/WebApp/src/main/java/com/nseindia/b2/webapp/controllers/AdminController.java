package com.nseindia.b2.webapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.nseindia.b2.webapp.models.Admin;
//import com.nseindia.b2.webapp.models.Blogger;
import com.nseindia.b2.webapp.models.Response;

@Controller
@RequestMapping("/")
public class AdminController {
	@Autowired
	RestTemplate restTemplate;
	
	
	@GetMapping
	public String index() {
		return "index";
	}
	
	@GetMapping("/admin")
	public String admin(Model model) {
		Admin list = restTemplate.getForObject("http://localhost:8081", Admin.class);
		model.addAttribute(list);
		model.addAttribute("Title", list.getTitle());
		model.addAttribute("Body", list.getBody());
		model.addAttribute("Summary", list.getSummary());
	
		return "admin"; 
	}
	
	
	@GetMapping("/AdminDetails")
	public String getAddAdmin() {
		return "AdminDetails";
	}
	

	
	@PostMapping("/AdminDetails/put")
	public String postAddAdmin(@RequestParam("title") String title, @RequestParam("body") String body,@RequestParam("summary") String summary, Model model) {
		
		Admin admin = new Admin();
		admin.setTitle(title);
		admin.setBody(body);
		admin.setSummary(summary);
		
		Response resp = restTemplate.postForObject("http://localhost:8081/", admin, Response.class);
		
		model.addAttribute("message",resp.getAdmin());
		
		return "AdminDetails";
	}
	

}