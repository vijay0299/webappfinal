package com.nseindia.b2.webapp.models;

import java.util.List;

public class BloggerList {
//	public String message;
	public Long id;
	public List<Blogger> list;

//	public String getMessage() {
//		return message;
//	}
//
//	public void setMessage(String message) {
//		this.message = message;
//	}

	public List<Blogger> getList() {
		return list;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setList(List<Blogger> list) {
		this.list = list;
	}

//	@Override
//	public String toString() {
//		return "BloggerList [message=" + message + ", list=" + list + "]";
//	}

}
