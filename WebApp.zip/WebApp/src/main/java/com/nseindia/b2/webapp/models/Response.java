package com.nseindia.b2.webapp.models;

public class Response {

	public String message;
	public Admin admin;
	public Blogger blogger;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Blogger getBlogger() {
		return blogger;
	}

	public void setBlogger(Blogger blogger) {
		this.blogger = blogger;
	}

	@Override
	public String toString() {
		return "Response [message=" + message + ", admin=" + admin + ", blogger=" + blogger + "]";
	}

}
